/**
 * WooCommerce Notices JS
 */
jQuery( function ( $ ) {

	$('.woocommerce-tracker .button-primary').on('click',function() {
		$('.woocommerce-tracker' ).slideUp();
	});

});