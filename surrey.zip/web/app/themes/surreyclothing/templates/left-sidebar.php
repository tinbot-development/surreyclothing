<?php dynamic_sidebar('left-sidebar'); ?>

